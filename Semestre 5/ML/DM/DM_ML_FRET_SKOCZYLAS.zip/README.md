## DM ML - Les transistors d'Ornicar

### Binôme :
FRET Gaëlle
SKOCZYLAS Nestor

### Organisation des fichiers :
Nous avons créé un fichier pour chaque question.
Tous les fichiers sont fonctionnels hormis celui de la question 5.

### Commandes :
Dans le dossier, sur votre terminal, tapez `ampl`.
Ecrivez ensuite `model <nom du fichier>`.
Ensuite le fichier se lancera avec les displays associés car nous avons ecrit les commandes nécessaires à chaque question dans les fichiers directement.